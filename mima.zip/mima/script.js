// 获取DOM元素
const passwordInput = document.getElementById("password");
const lengthSlider = document.getElementById("length");
const lengthDisplay = document.getElementById("length-value");
const uppercaseCheckbox = document.getElementById("uppercase");
const lowercaseCheckbox = document.getElementById("lowercase");
const numbersCheckbox = document.getElementById("numbers");
const symbolsCheckbox = document.getElementById("symbols");
const generateButton = document.getElementById("generate-btn");
const copyButton = document.getElementById("copy-btn");
const strengthBar = document.querySelector(".strength-bar");
const strengthLabel = document.getElementById("strength-label");

// 字符集定义
const uppercaseLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const lowercaseLetters = "abcdefghijklmnopqrstuvwxyz";
const numberCharacters = "0123456789";
const symbolCharacters = "!@#$%^&*()-_=+[]{}|;:,.<>?/";

// 同步显示密码长度
lengthSlider.addEventListener("input", () => {
  lengthDisplay.textContent = lengthSlider.value;
});

// 生成密码按钮事件
generateButton.addEventListener("click", makePassword);

// 生成密码函数
function makePassword() {
  const length = Number(lengthSlider.value);
  const includeUppercase = uppercaseCheckbox.checked;
  const includeLowercase = lowercaseCheckbox.checked;
  const includeNumbers = numbersCheckbox.checked;
  const includeSymbols = symbolsCheckbox.checked;
  
  // 验证至少选择一种字符类型
  if (!includeUppercase && !includeLowercase && !includeNumbers && !includeSymbols) {
    alert("请至少选择一种字符类型");
    return;
  }
  
  // 生成密码并显示
  const newPassword = createRandomPassword(
    length,
    includeUppercase,
    includeLowercase,
    includeNumbers,
    includeSymbols
  );
  passwordInput.value = newPassword;
  
  // 更新密码强度指示
  updateStrengthMeter(newPassword);
}

// 随机密码生成函数
function createRandomPassword(
  length,
  includeUppercase,
  includeLowercase,
  includeNumbers,
  includeSymbols
) {
  let allCharacters = "";
  
  // 根据选择的选项构建字符集
  if (includeUppercase) allCharacters += uppercaseLetters;
  if (includeLowercase) allCharacters += lowercaseLetters;
  if (includeNumbers) allCharacters += numberCharacters;
  if (includeSymbols) allCharacters += symbolCharacters;
  
  let password = "";
  
  // 生成指定长度的随机密码
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * allCharacters.length);
    password += allCharacters[randomIndex];
  }
  
  return password;
}

// 更新密码强度指示条
function updateStrengthMeter(password) {
  const passwordLength = password.length;
  
  // 检查密码包含的字符类型
  const hasUppercase = /[A-Z]/.test(password);
  const hasLowercase = /[a-z]/.test(password);
  const hasNumbers = /[0-9]/.test(password);
  const hasSymbols = /[!@#$%^&*()-_=+[\]{}|;:,.<>?]/.test(password);

  let strengthScore = 0;
  
  // 基于长度计算分数（最长20个字符，超过20不再加分）
  strengthScore += Math.min(passwordLength * 2, 40);
  
  // 每种字符类型加15分
  if (hasUppercase) strengthScore += 15;
  if (hasLowercase) strengthScore += 15;
  if (hasNumbers) strengthScore += 15;
  if (hasSymbols) strengthScore += 15;

  // 短密码强度上限
  if (passwordLength < 8) {
    strengthScore = Math.min(strengthScore, 40);
  }

  // 确保分数在5-100之间
  const safeScore = Math.max(5, Math.min(100, strengthScore));
  strengthBar.style.width = safeScore + "%";

  let strengthLabelText = "";
  let barColor = "";

  // 设置强度文本和颜色
  if (strengthScore < 40) {
    barColor = "#fc8181"; // 红色 - 弱
    strengthLabelText = "弱";
  } else if (strengthScore < 70) {
    barColor = "#fbd38d"; // 黄色 - 中等
    strengthLabelText = "中等";
  } else {
    barColor = "#68d391"; // 绿色 - 强
    strengthLabelText = "强";
  }

  strengthBar.style.backgroundColor = barColor;
  strengthLabel.textContent = strengthLabelText;
}

// 复制密码功能
copyButton.addEventListener("click", () => {
  if (!passwordInput.value) return;

  navigator.clipboard
    .writeText(passwordInput.value)
    .then(() => showCopySuccess())
    .catch((error) => console.log("复制失败:", error));
});

// 显示复制成功状态
function showCopySuccess() {
  copyButton.classList.remove("far", "fa-copy");
  copyButton.classList.add("fas", "fa-check");
  copyButton.style.color = "#48bb78";

  // 1.5秒后恢复原始状态
  setTimeout(() => {
    copyButton.classList.remove("fas", "fa-check");
    copyButton.classList.add("far", "fa-copy");
    copyButton.style.color = "";
  }, 1500);
}

// 页面加载时生成初始密码
window.addEventListener("DOMContentLoaded", makePassword);